const registerController = {
    async registerUser(req, res){
        return
    }
}
export default registerController